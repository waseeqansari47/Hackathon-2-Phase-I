"""
Task model for the Todo CLI application.

This module defines the Task entity with its properties and validation rules.
"""

from typing import Dict, Any


class Task:
    """
    Represents a single todo item with properties including unique ID,
    description text, and completion status.
    """

    def __init__(self, task_id: int, description: str, completed: bool = False):
        """
        Initialize a Task instance.

        Args:
            task_id: Unique identifier for the task
            description: Task description text
            completed: Completion status (default: False)

        Raises:
            ValueError: If description is empty or None
        """
        if not description or not description.strip():
            raise ValueError("Task description cannot be empty or None")

        if not isinstance(task_id, int):
            raise ValueError("Task ID must be an integer")

        self.id = task_id
        self.description = description.strip()
        self.completed = completed

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the Task instance to a dictionary representation.

        Returns:
            Dictionary containing task properties
        """
        return {
            'id': self.id,
            'description': self.description,
            'completed': self.completed
        }

    def __str__(self) -> str:
        """
        String representation of the Task.

        Returns:
            Formatted string showing task ID, status, and description
        """
        status = "✓" if self.completed else "○"
        return f"[{status}] {self.id}: {self.description}"


class TaskList:
    """
    Collection of Task entities managed by the application.
    """

    def __init__(self):
        """Initialize an empty TaskList."""
        self._tasks = []
        self._id_map = {}  # Maps ID to task index for O(1) access

    def add_task(self, task: Task) -> None:
        """
        Add a task to the list.

        Args:
            task: Task instance to add

        Raises:
            ValueError: If task ID already exists
        """
        if task.id in self._id_map:
            raise ValueError(f"Task with ID {task.id} already exists")

        index = len(self._tasks)
        self._tasks.append(task)
        self._id_map[task.id] = index

    def get_task(self, task_id: int) -> Task:
        """
        Retrieve a task by its ID.

        Args:
            task_id: ID of the task to retrieve

        Returns:
            Task instance

        Raises:
            KeyError: If task ID does not exist
        """
        if task_id not in self._id_map:
            raise KeyError(f"Task with ID {task_id} does not exist")

        index = self._id_map[task_id]
        return self._tasks[index]

    def update_task(self, task_id: int, new_description: str = None,
                   completed: bool = None) -> Task:
        """
        Update an existing task.

        Args:
            task_id: ID of the task to update
            new_description: New description (optional)
            completed: New completion status (optional)

        Returns:
            Updated Task instance

        Raises:
            KeyError: If task ID does not exist
            ValueError: If new description is empty
        """
        task = self.get_task(task_id)

        if new_description is not None:
            if not new_description or not new_description.strip():
                raise ValueError("Task description cannot be empty or None")
            task.description = new_description.strip()

        if completed is not None:
            task.completed = completed

        return task

    def delete_task(self, task_id: int) -> Task:
        """
        Remove a task from the list.

        Args:
            task_id: ID of the task to remove

        Returns:
            The deleted Task instance

        Raises:
            KeyError: If task ID does not exist
        """
        if task_id not in self._id_map:
            raise KeyError(f"Task with ID {task_id} does not exist")

        index = self._id_map[task_id]
        task = self._tasks.pop(index)

        # Update the ID map to account for the removed element
        del self._id_map[task_id]

        # Update indices for tasks after the removed one
        for i in range(index, len(self._tasks)):
            current_task = self._tasks[i]
            self._id_map[current_task.id] = i

        return task

    def toggle_task_status(self, task_id: int) -> Task:
        """
        Toggle the completion status of a task.

        Args:
            task_id: ID of the task to toggle

        Returns:
            Updated Task instance with toggled status

        Raises:
            KeyError: If task ID does not exist
        """
        task = self.get_task(task_id)
        task.completed = not task.completed
        return task

    def list_all_tasks(self) -> list:
        """
        Get all tasks in the list.

        Returns:
            List of all Task instances
        """
        return self._tasks.copy()

    def get_next_id(self) -> int:
        """
        Get the next available task ID.

        Returns:
            Next available integer ID
        """
        if not self._tasks:
            return 1

        # Find the maximum ID currently in use and add 1
        max_id = max(task.id for task in self._tasks)
        return max_id + 1