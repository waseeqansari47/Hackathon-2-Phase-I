"""
Entry point for the Todo CLI application.

This module initializes the application components and starts the main menu loop.
"""

from .storage.in_memory_storage import InMemoryStorage
from .services.task_service import TaskService
from .ui.cli_menu import CLIMenu


def main():
    """
    Main entry point for the Todo CLI application.

    Initializes the storage, service, and UI layers, then starts the application.
    """
    print("Initializing Todo List Application...")

    # Initialize the storage layer
    storage = InMemoryStorage()

    # Initialize the service layer with the storage
    task_service = TaskService(storage)

    # Initialize the UI layer with the service
    cli_menu = CLIMenu(task_service)

    # Start the application
    try:
        cli_menu.run()
    except KeyboardInterrupt:
        print("\n\nApplication interrupted. Exiting gracefully...")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        print("Exiting...")


if __name__ == "__main__":
    main()