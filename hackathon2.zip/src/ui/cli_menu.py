"""
CLI Menu interface for the Todo CLI application.

This module implements the menu-driven interface that allows users to
interact with the application through an intuitive command-line menu.
"""

import sys
from typing import Optional
from ..services.task_service import TaskService


class CLIMenu:
    """
    Implements a menu-driven interface for the Todo CLI application.
    Provides an intuitive way for users to interact with task management features.
    """

    def __init__(self, task_service: TaskService):
        """
        Initialize the CLI Menu with a task service instance.

        Args:
            task_service: TaskService instance to handle task operations
        """
        self.task_service = task_service
        self.running = True

    def display_menu(self) -> None:
        """
        Display the main menu with available options.
        """
        print("\n" + "="*40)
        print("         TODO LIST APPLICATION")
        print("="*40)
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Update Task")
        print("4. Delete Task")
        print("5. Toggle Task Status")
        print("6. Exit")
        print("="*40)

    def get_user_choice(self) -> str:
        """
        Get user's menu choice.

        Returns:
            String representing user's choice
        """
        try:
            choice = input("Enter your choice (1-6): ").strip()
            return choice
        except (EOFError, KeyboardInterrupt):
            print("\n\nApplication interrupted. Exiting...")
            return "6"  # Return exit option

    def handle_add_task(self) -> None:
        """
        Handle the add task operation.
        """
        try:
            description = input("Enter task description: ").strip()

            if not description:
                print("Error: Task description cannot be empty.")
                return

            task = self.task_service.add_task(description)
            print(f"Task added successfully with ID: {task.id}")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Unexpected error occurred while adding task: {e}")

    def handle_view_tasks(self) -> None:
        """
        Handle the view tasks operation.
        """
        try:
            tasks = self.task_service.list_all_tasks()

            if not tasks:
                print("No tasks found.")
                return

            print("\nCurrent Tasks:")
            print("-" * 50)
            for task in tasks:
                status_icon = "✓" if task.completed else "○"
                print(f"[{status_icon}] ID: {task.id} | {task.description}")
            print("-" * 50)
        except Exception as e:
            print(f"Error occurred while retrieving tasks: {e}")

    def handle_update_task(self) -> None:
        """
        Handle the update task operation.
        """
        try:
            task_id_str = input("Enter task ID to update: ").strip()

            if not task_id_str.isdigit():
                print("Error: Task ID must be a number.")
                return

            task_id = int(task_id_str)

            # Check if task exists
            try:
                current_task = self.task_service.get_task(task_id)
            except KeyError:
                print(f"Error: Task with ID {task_id} does not exist.")
                return

            print(f"Current task: {current_task.description}")
            new_description = input("Enter new description (press Enter to skip): ").strip()

            if not new_description:
                print("No changes made to description.")
                return

            if not new_description.strip():
                print("Error: Task description cannot be empty.")
                return

            updated_task = self.task_service.update_task(task_id, new_description)
            print(f"Task updated successfully. New description: {updated_task.description}")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Unexpected error occurred while updating task: {e}")

    def handle_delete_task(self) -> None:
        """
        Handle the delete task operation.
        """
        try:
            task_id_str = input("Enter task ID to delete: ").strip()

            if not task_id_str.isdigit():
                print("Error: Task ID must be a number.")
                return

            task_id = int(task_id_str)

            # Check if task exists
            try:
                task = self.task_service.get_task(task_id)
            except KeyError:
                print(f"Error: Task with ID {task_id} does not exist.")
                return

            confirm = input(f"Are you sure you want to delete task '{task.description}'? (y/N): ").strip().lower()

            if confirm in ['y', 'yes']:
                deleted_task = self.task_service.delete_task(task_id)
                print(f"Task '{deleted_task.description}' deleted successfully.")
            else:
                print("Task deletion cancelled.")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Unexpected error occurred while deleting task: {e}")

    def handle_toggle_task(self) -> None:
        """
        Handle the toggle task status operation.
        """
        try:
            task_id_str = input("Enter task ID to toggle: ").strip()

            if not task_id_str.isdigit():
                print("Error: Task ID must be a number.")
                return

            task_id = int(task_id_str)

            # Check if task exists
            try:
                task = self.task_service.get_task(task_id)
            except KeyError:
                print(f"Error: Task with ID {task_id} does not exist.")
                return

            updated_task = self.task_service.toggle_task_completion(task_id)
            status = "completed" if updated_task.completed else "incomplete"
            print(f"Task status updated to {status}.")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Unexpected error occurred while toggling task: {e}")

    def handle_exit(self) -> None:
        """
        Handle the exit operation.
        """
        print("Thank you for using the Todo List Application!")
        self.running = False

    def handle_invalid_choice(self, choice: str) -> None:
        """
        Handle invalid user choice.

        Args:
            choice: The invalid choice entered by the user
        """
        print(f"Invalid choice: '{choice}'. Please enter a number between 1 and 6.")

    def run(self) -> None:
        """
        Run the main menu loop.
        """
        print("Welcome to the Todo List Application!")

        while self.running:
            self.display_menu()
            choice = self.get_user_choice()

            if choice == "1":
                self.handle_add_task()
            elif choice == "2":
                self.handle_view_tasks()
            elif choice == "3":
                self.handle_update_task()
            elif choice == "4":
                self.handle_delete_task()
            elif choice == "5":
                self.handle_toggle_task()
            elif choice == "6":
                self.handle_exit()
            else:
                self.handle_invalid_choice(choice)

            # Pause to let user see the result before showing the menu again
            if self.running:
                input("\nPress Enter to continue...")