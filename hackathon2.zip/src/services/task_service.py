"""
Task Service for the Todo CLI application.

This module implements the business logic for task operations,
handling all task-related functionality with proper validation.
"""

from typing import List, Optional
from ..models.task import Task
from ..storage.in_memory_storage import InMemoryStorage


class TaskService:
    """
    Provides business logic for task operations including validation,
    error handling, and coordination between models and storage.
    """

    def __init__(self, storage: InMemoryStorage):
        """
        Initialize the Task Service with a storage instance.

        Args:
            storage: InMemoryStorage instance to use for data persistence
        """
        self.storage = storage

    def add_task(self, description: str) -> Task:
        """
        Add a new task with the given description.

        Args:
            description: Description for the new task

        Returns:
            The newly created Task instance with assigned ID

        Raises:
            ValueError: If description is empty or None
        """
        if not description or not description.strip():
            raise ValueError("Task description cannot be empty or None")

        # Generate a unique ID for the new task
        new_id = self.storage.get_next_id()
        task = Task(new_id, description.strip())
        self.storage.add_task(task)
        return task

    def get_task(self, task_id: int) -> Task:
        """
        Retrieve a task by its ID.

        Args:
            task_id: ID of the task to retrieve

        Returns:
            Task instance

        Raises:
            KeyError: If task ID does not exist
        """
        return self.storage.get_task(task_id)

    def update_task(self, task_id: int, new_description: str = None,
                   completed: bool = None) -> Task:
        """
        Update an existing task with new information.

        Args:
            task_id: ID of the task to update
            new_description: New description (optional)
            completed: New completion status (optional)

        Returns:
            Updated Task instance

        Raises:
            KeyError: If task ID does not exist
            ValueError: If new description is empty
        """
        return self.storage.update_task(task_id, new_description, completed)

    def delete_task(self, task_id: int) -> Task:
        """
        Remove a task from the system.

        Args:
            task_id: ID of the task to remove

        Returns:
            The deleted Task instance

        Raises:
            KeyError: If task ID does not exist
        """
        return self.storage.delete_task(task_id)

    def toggle_task_completion(self, task_id: int) -> Task:
        """
        Toggle the completion status of a task.

        Args:
            task_id: ID of the task to toggle

        Returns:
            Updated Task instance with toggled completion status

        Raises:
            KeyError: If task ID does not exist
        """
        return self.storage.toggle_task_status(task_id)

    def list_all_tasks(self) -> List[Task]:
        """
        Get all tasks in the system.

        Returns:
            List of all Task instances
        """
        return self.storage.list_all_tasks()

    def validate_task_description(self, description: str) -> bool:
        """
        Validate a task description.

        Args:
            description: Description to validate

        Returns:
            True if description is valid, False otherwise
        """
        if not description or not description.strip():
            return False
        return True

    def validate_task_id(self, task_id: int) -> bool:
        """
        Validate a task ID.

        Args:
            task_id: ID to validate

        Returns:
            True if ID is valid (exists in storage), False otherwise
        """
        if not isinstance(task_id, int) or task_id <= 0:
            return False
        return self.storage.task_exists(task_id)