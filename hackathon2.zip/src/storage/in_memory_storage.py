"""
In-memory storage implementation for the Todo CLI application.

This module provides storage functionality using Python's built-in data
structures, maintaining data only in memory during application runtime.
"""

from typing import List, Optional
from ..models.task import Task, TaskList


class InMemoryStorage:
    """
    Implements in-memory storage for tasks using Python's built-in data structures.
    Data exists only during application runtime and is lost when the application exits.
    """

    def __init__(self):
        """
        Initialize the in-memory storage with an empty task list.
        """
        self._task_list = TaskList()

    def add_task(self, task: Task) -> None:
        """
        Add a task to the in-memory storage.

        Args:
            task: Task instance to add to storage

        Raises:
            ValueError: If task ID already exists
        """
        self._task_list.add_task(task)

    def get_task(self, task_id: int) -> Task:
        """
        Retrieve a task from storage by its ID.

        Args:
            task_id: ID of the task to retrieve

        Returns:
            Task instance

        Raises:
            KeyError: If task ID does not exist in storage
        """
        return self._task_list.get_task(task_id)

    def update_task(self, task_id: int, new_description: str = None,
                   completed: bool = None) -> Task:
        """
        Update an existing task in storage.

        Args:
            task_id: ID of the task to update
            new_description: New description (optional)
            completed: New completion status (optional)

        Returns:
            Updated Task instance

        Raises:
            KeyError: If task ID does not exist
            ValueError: If new description is empty
        """
        return self._task_list.update_task(task_id, new_description, completed)

    def delete_task(self, task_id: int) -> Task:
        """
        Remove a task from storage.

        Args:
            task_id: ID of the task to remove

        Returns:
            The deleted Task instance

        Raises:
            KeyError: If task ID does not exist
        """
        return self._task_list.delete_task(task_id)

    def toggle_task_status(self, task_id: int) -> Task:
        """
        Toggle the completion status of a task in storage.

        Args:
            task_id: ID of the task to toggle

        Returns:
            Updated Task instance with toggled status

        Raises:
            KeyError: If task ID does not exist
        """
        return self._task_list.toggle_task_status(task_id)

    def list_all_tasks(self) -> List[Task]:
        """
        Get all tasks from storage.

        Returns:
            List of all Task instances in storage
        """
        return self._task_list.list_all_tasks()

    def get_next_id(self) -> int:
        """
        Get the next available task ID.

        Returns:
            Next available integer ID
        """
        return self._task_list.get_next_id()

    def task_exists(self, task_id: int) -> bool:
        """
        Check if a task with the given ID exists in storage.

        Args:
            task_id: ID to check for existence

        Returns:
            True if task exists, False otherwise
        """
        try:
            self.get_task(task_id)
            return True
        except KeyError:
            return False