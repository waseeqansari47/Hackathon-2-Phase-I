# Manual Test Scenarios: Todo CLI Application

## Test Scenario: ADD_TASK Operation

**Objective**: Verify that users can add new tasks to the todo list.

**Prerequisites**:
- Application is running
- User has access to the main menu

**Steps**:
1. Start the application
2. From the main menu, select option "1" (Add Task)
3. Enter a valid task description (e.g., "Buy groceries")
4. Press Enter

**Expected Result**:
- Task is successfully added to the list
- User sees confirmation message with assigned task ID
- Task appears in subsequent task lists

**Test Data**:
- Valid description: "Buy groceries"
- Valid description: "Finish project report"
- Valid description: "Call dentist appointment"

---

## Test Scenario: VIEW_TASKS Operation

**Objective**: Verify that users can view all tasks in the todo list.

**Prerequisites**:
- Application is running
- At least one task exists in the system

**Steps**:
1. Ensure at least one task exists (add one if needed)
2. From the main menu, select option "2" (View Tasks)
3. Observe the displayed task list

**Expected Result**:
- All tasks are displayed with their ID, completion status, and description
- Format: [Status Icon] ID: X | Description
- Status icon is "○" for incomplete, "✓" for complete

**Test Data**:
- Empty task list (should show "No tasks found")
- List with 1 task
- List with multiple tasks (mixed completion status)

---

## Test Scenario: UPDATE_TASK Operation

**Objective**: Verify that users can update existing task descriptions.

**Prerequisites**:
- Application is running
- At least one task exists in the system

**Steps**:
1. From the main menu, select option "3" (Update Task)
2. Enter the ID of an existing task
3. Enter a new description for the task
4. Press Enter

**Expected Result**:
- Task description is updated successfully
- User sees confirmation message
- Updated task appears with new description when viewed

**Test Data**:
- Valid task ID with new description
- Non-existent task ID (should show error)
- Empty description (should show error)

---

## Test Scenario: DELETE_TASK Operation

**Objective**: Verify that users can delete tasks from the todo list.

**Prerequisites**:
- Application is running
- At least one task exists in the system

**Steps**:
1. From the main menu, select option "4" (Delete Task)
2. Enter the ID of an existing task
3. Confirm deletion when prompted
4. Press Enter

**Expected Result**:
- Task is removed from the list
- User sees confirmation message
- Task no longer appears when viewing the list

**Test Data**:
- Valid task ID (should delete successfully)
- Non-existent task ID (should show error)
- Cancel deletion (should not delete)

---

## Test Scenario: TOGGLE_TASK Operation

**Objective**: Verify that users can toggle task completion status.

**Prerequisites**:
- Application is running
- At least one task exists in the system

**Steps**:
1. From the main menu, select option "5" (Toggle Task Status)
2. Enter the ID of an existing task
3. Press Enter

**Expected Result**:
- Task completion status is switched (incomplete → complete or complete → incomplete)
- User sees confirmation message
- Updated status appears when viewing the task list

**Test Data**:
- Incomplete task (should become complete)
- Complete task (should become incomplete)
- Non-existent task ID (should show error)