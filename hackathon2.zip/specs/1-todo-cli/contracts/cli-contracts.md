# CLI Operation Contracts: Todo CLI Application

## Operation: ADD_TASK
**Command**: `add` or Option 1 in menu
**Parameters**:
- `description`: String (required task description)
**Response**:
- Success: Confirmation message with assigned task ID
- Error: Error message if description is empty
**Behavior**: Creates a new task with the given description and assigns a unique ID

## Operation: VIEW_TASKS
**Command**: `view` or Option 2 in menu
**Parameters**: None
**Response**:
- Success: List of all tasks showing ID, completion status, and description
- Error: None (empty list if no tasks exist)
**Behavior**: Displays all tasks in the current session

## Operation: UPDATE_TASK
**Command**: `update` or Option 3 in menu
**Parameters**:
- `id`: Integer (task identifier)
- `new_description`: String (updated task description)
**Response**:
- Success: Confirmation message of update
- Error: Error message if task ID doesn't exist or description is empty
**Behavior**: Updates the description of an existing task

## Operation: DELETE_TASK
**Command**: `delete` or Option 4 in menu
**Parameters**:
- `id`: Integer (task identifier)
**Response**:
- Success: Confirmation message of deletion
- Error: Error message if task ID doesn't exist
**Behavior**: Removes the specified task from the list

## Operation: TOGGLE_TASK
**Command**: `toggle` or Option 5 in menu
**Parameters**:
- `id`: Integer (task identifier)
**Response**:
- Success: Confirmation message of status change
- Error: Error message if task ID doesn't exist
**Behavior**: Switches the completion status of the specified task

## Operation: EXIT
**Command**: `exit` or Option 6 in menu
**Parameters**: None
**Response**: Application termination
**Behavior**: Gracefully closes the application