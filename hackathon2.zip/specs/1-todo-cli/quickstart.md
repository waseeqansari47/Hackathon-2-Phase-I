# Quickstart Guide: Todo CLI Application

## Running the Application

1. Ensure Python 3.13+ is installed on your system
2. Navigate to the project root directory
3. Run the application using: `python -m src`

## Using the Application

When the application starts, you'll see a menu with the following options:

1. **Add Task**: Enter a new task description
2. **View Tasks**: Display all current tasks with their status
3. **Update Task**: Change the description of an existing task
4. **Delete Task**: Remove a task from the list
5. **Toggle Task Status**: Mark a task as complete/incomplete
6. **Exit**: Quit the application

### Example Usage:
1. Select "Add Task" and enter "Buy groceries"
2. Select "View Tasks" to see your task list
3. Select "Toggle Task Status" to mark the task as complete
4. Continue managing your tasks as needed

## Manual Testing Steps

1. Start the application
2. Add multiple tasks with different descriptions
3. View the task list to verify all tasks appear correctly
4. Update a task description
5. Toggle task completion status
6. Delete a task
7. Verify that operations work as expected
8. Test error handling by attempting invalid operations