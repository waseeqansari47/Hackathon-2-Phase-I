# Data Model: Todo CLI Application

## Task Entity

**Fields:**
- `id`: Integer (auto-generated, unique identifier)
- `description`: String (task description text, required)
- `completed`: Boolean (completion status, default: False)

**Validation Rules:**
- `id` must be unique within the task list
- `description` must not be empty or None
- `completed` must be either True or False

**State Transitions:**
- `completed` can transition from False to True (mark complete)
- `completed` can transition from True to False (mark incomplete)

## TaskList Collection

**Structure:**
- Internal storage: Python list of Task objects
- Index lookup: Dictionary mapping id to Task object position for O(1) access

**Operations:**
- Add Task: Append to list, assign next available ID
- Get Task: Retrieve by ID
- Update Task: Modify existing task by ID
- Delete Task: Remove from list by ID
- Toggle Completion: Switch completed status by ID
- List All Tasks: Return all tasks

**Constraints:**
- All operations must maintain data integrity
- Operations must be thread-safe if needed in future phases
- Task IDs must remain consistent across operations